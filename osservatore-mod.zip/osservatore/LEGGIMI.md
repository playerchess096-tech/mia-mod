# L'Osservatore - mod horror per Minecraft

Qualcosa vive in questo mondo. Ti parla nella chat, ti osserva e reagisce a quello che fai.

- **Minecraft Java 26.3** con **Fabric** (Loader 0.19.5+, Fabric API 0.161.0+26.3)
- Serve **Java 25**
- Funziona nei mondi singoli e sui server (lato server: sui server basta installarla lì)

## Cosa fa

**Parla nella chat** come `<Osservatore>` e risponde a quello che scrivi: prova `ciao`, `chi sei?`,
`dove sei?`, `aiuto`, `ho paura`, `ahah`... Sulle frasi che non conosce risponde a volte con un'eco
(a volte al contrario). Conosce anche le tue coordinate, i tuoi cuori e l'oggetto che hai in mano.

**Reagisce a quello che fai:** quando muori, vai a dormire, rompi diamanti, detriti antichi o uno spawner.

**Eventi horror**, sempre più pesanti col passare del tempo (e con le tue morti):

| Evento | Cosa succede |
|---|---|
| `sussurro` | un rumore di caverna lontano, poi una frase nella chat |
| `passi` | passi che si avvicinano da dietro, sempre più vicini |
| `porta` | una porta / un baule / una botola si apre e si richiude vicino a te |
| `creeper` | il sibilo di un creeper dietro di te... che poi non esplode |
| `tuono` | un tuono lontanissimo, anche col cielo sereno |
| `respiro` | battito del cuore che accelera e vista che si restringe |
| `falso_ingresso` | "Osservatore è entrato nel gioco"... poi parla... poi "ha lasciato il gioco" |
| `ombra` | una figura alta e immobile in lontananza che ti fissa e **sparisce quando la guardi** |
| `buio` | il buio si chiude attorno a te, poi un attimo di cecità |
| `coordinate` | ti dice dove sei, con anime di sculk e un sussulto della telecamera |
| `disco11` | parte il disco "11" (raro) |
| `jumpscare` | urlo, schermo che trema, titolo disturbato, buio e nausea (raro) |

**Stadi:** 0 sussurri -> 1 rumori -> 2 presenza (ombra, falso ingresso, buio) -> 3 spaventi veri.
Si sale ogni 6 minuti nel mondo, più ogni 2 morti.

## Come ottenere il file .jar

### Metodo A - GitHub (senza PC, va bene anche da telefono)
1. Crea un repository su GitHub e carica **tutta questa cartella** (anche la cartella nascosta `.github`).
2. Apri la scheda **Actions** -> **Compila la mod**. Parte da sola a ogni push (o con "Run workflow").
3. A fine lavoro scarica l'artefatto **osservatore-mod**: dentro c'è `osservatore-1.0.0.jar`.

### Metodo B - Dal PC
Servono JDK 25 e Gradle 9.6 (o più recente):

```
gradle build
```

Il file esce in `build/libs/osservatore-1.0.0.jar` (ignora quello `-sources`).

## Installazione
1. Installa **Fabric Loader** per Minecraft 26.3 (launcher Fabric o installer da fabricmc.net).
2. Metti nella cartella `mods` sia `osservatore-1.0.0.jar` sia **Fabric API**.
3. Avvia il gioco e crea un mondo. Dopo una decina di secondi arriva il primo messaggio.

## Provarla subito
- Scrivi `ciao` nella chat.
- Con i **trucchi attivi** (Consenti trucchi: sì) puoi usare i comandi qui sotto.
- Per vedere tutto in fretta: `/osservatore intensita 3` e `/osservatore evento jumpscare`.

## Comandi (livello gamemaster)

| Comando | Cosa fa |
|---|---|
| `/osservatore` | stato e lista degli eventi |
| `/osservatore evento` | un evento a caso, subito |
| `/osservatore evento <nome>` | un evento preciso (premi Tab per i nomi) |
| `/osservatore parla <testo>` | l'Osservatore scrive nella tua chat |
| `/osservatore intensita <0-3>` | 0 spento, 1 lieve, 2 normale, 3 incubo |
| `/osservatore pulisci` | toglie le figure lontane rimaste nel mondo |

## Configurazione
Al primo avvio si crea `config/osservatore.properties` (con i commenti):
`intensita`, `nome` (come si chiama nella chat), `secondi_min` / `secondi_max` (ogni quanto può succedere
qualcosa), `probabilita_risposta`, `jumpscare`, `ombra`, `falso_ingresso`.
Se rompi qualcosa, cancella il file: viene ricreato.

## Cambiare le frasi
Tutte le frasi sono in `src/main/java/com/osservatore/Lines.java`: sono semplici elenchi di testo.
Puoi usare questi segnaposto: `{nome}` `{x}` `{y}` `{z}` `{cuori}` `{oggetto}`.
Le risposte alla chat sono nella lista `REPLIES` in fondo allo stesso file (parole chiave -> risposte).

## Com'è fatta
- `OsservatoreMod` - collega gli eventi di Fabric (chat, morte, sonno, blocchi, comandi)
- `Director` - decide cosa succede, quando e a chi; contiene tutti gli eventi
- `Lines` - le frasi · `Voice` - come appare il testo nella chat
- `Fx` - suoni, particelle, effetti, titoli (usa i normali comandi di Minecraft, così cambia poco da una versione all'altra)
- `Config`, `Scheduler`, `OsservatoreCommand` - impostazioni, messaggi ritardati, comando

## Aggiornare a un'altra versione di Minecraft
Cambia i numeri in `gradle.properties` (li trovi su https://fabricmc.net/develop) e il campo
`minecraft` in `src/main/resources/fabric.mod.json`. Se il compilatore segnala errori su qualche
nome di classe, mandali a chi ti ha dato la mod: di solito sono pochi e veloci da sistemare.
