package com.osservatore;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * L'Osservatore: una mod lato server (funziona anche nei mondi singoli).
 * Qui si collegano solo gli eventi di Fabric: il resto della logica è in {@link Director}.
 */
public class OsservatoreMod implements ModInitializer {

    public static final String MOD_ID = "osservatore";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        Config config = Config.load();
        Director director = new Director(config);

        // Ogni tick del server: eventi casuali, ombra, messaggi pianificati
        ServerTickEvents.END_SERVER_TICK.register(director::onTick);
        ServerLifecycleEvents.SERVER_STOPPING.register(director::onServerStopping);

        // Il giocatore scrive nella chat -> l'Osservatore risponde
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) ->
                director.onChat(sender.getUUID(), message.signedContent()));

        // Il giocatore muore
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayer player) {
                director.onDeath(player.getUUID());
            }
        });

        // Il giocatore va a dormire
        EntitySleepEvents.START_SLEEPING.register((entity, sleepingPos) -> {
            if (entity instanceof ServerPlayer player) {
                director.onSleep(player.getUUID());
            }
        });

        // Il giocatore rompe diamanti, detriti antichi, spawner...
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
            if (player instanceof ServerPlayer serverPlayer) {
                String blockId = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
                director.onBlockBroken(serverPlayer.getUUID(), blockId);
            }
        });

        // Il comando /osservatore
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                OsservatoreCommand.register(dispatcher, director, config));

        LOGGER.info("L'Osservatore e' sveglio (intensita {}).", config.intensity);
    }
}
