package com.osservatore;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.Locale;
import java.util.Random;

/** Come "suona" l'Osservatore nella chat: colori, testo disturbato, finti messaggi di sistema. */
final class Voice {

    private static final Random RND = new Random();

    private Voice() {}

    /** {@code <Osservatore> testo}: stile chat normale ma rosso. In modalità "loud" è un urlo. */
    static MutableComponent speech(Config cfg, String text, boolean loud) {
        MutableComponent name = Component.literal("<" + cfg.entityName + "> ").withStyle(ChatFormatting.DARK_RED);
        MutableComponent body = loud
                ? Component.literal(text.toUpperCase(Locale.ROOT)).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)
                : Component.literal(text).withStyle(ChatFormatting.RED);
        return Component.empty().append(name).append(body);
    }

    /** Testo "narrato": grigio scuro in corsivo, senza nome. */
    static MutableComponent narration(String text) {
        return Component.literal(text).withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC);
    }

    /** Testo con qualche parola "corrotta" (effetto §k, le lettere si mescolano). */
    static MutableComponent glitch(String text, ChatFormatting... styles) {
        MutableComponent out = Component.empty();
        String[] words = text.split(" ");
        for (int i = 0; i < words.length; i++) {
            MutableComponent piece = Component.literal(words[i]).withStyle(styles);
            if (RND.nextInt(5) == 0) {
                piece = piece.withStyle(ChatFormatting.OBFUSCATED);
            }
            out.append(piece);
            if (i < words.length - 1) {
                out.append(Component.literal(" "));
            }
        }
        return out;
    }

    /** Il classico messaggio di sistema "X è entrato nel gioco" (tradotto dalla lingua del client). */
    static MutableComponent fakeJoined(Config cfg) {
        return Component.translatable("multiplayer.player.joined", Component.literal(cfg.entityName))
                .withStyle(ChatFormatting.YELLOW);
    }

    /** ...e "X ha lasciato il gioco". */
    static MutableComponent fakeLeft(Config cfg) {
        return Component.translatable("multiplayer.player.left", Component.literal(cfg.entityName))
                .withStyle(ChatFormatting.YELLOW);
    }
}
