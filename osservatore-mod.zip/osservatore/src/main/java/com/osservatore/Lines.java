package com.osservatore;

import net.minecraft.server.level.ServerPlayer;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Tutte le frasi dell'Osservatore. Sono solo testo: modificale, aggiungine, cancellale.
 * Segnaposto: {nome} {x} {y} {z} {cuori} {oggetto} (l'oggetto che hai in mano).
 */
final class Lines {

    private Lines() {}

    // ------------------------------------------------------------------
    // Quando entri nel mondo (sequenze di messaggi, uno dopo l'altro)
    // ------------------------------------------------------------------
    static final String[][] WELCOME = {
            {"Ciao, {nome}.", "Ti stavo aspettando."},
            {"Sei tornato.", "Questo mondo si ricorda di te."},
            {"{nome}...", "Non guardarti intorno. Non ancora."},
            {"Ho sentito i tuoi passi da molto lontano.", "Adesso sono più vicino di quanto pensi."},
            {"Finalmente.", "Pensavo che non saresti più venuto."},
    };

    // ------------------------------------------------------------------
    // Sussurri casuali, divisi per "stadio" di paura
    // ------------------------------------------------------------------
    static final String[] AMBIENT_1 = {
            "Lo senti anche tu?",
            "Qualcuno ti sta guardando.",
            "Non sei mai stato solo qui.",
            "Hai chiuso bene la porta?",
            "Le ombre non sono vuote.",
            "Il silenzio è solo qualcuno che trattiene il respiro.",
            "Alle tue spalle, {nome}.",
            "Sei a {x}, {y}, {z}. Lo so sempre.",
            "Hai {cuori} cuori. Sono pochi, se succede qualcosa.",
            "Conto i tuoi passi.",
            "Perché continui a scavare? Non ti piace la luce?",
            "Sotto di te qualcosa sta ascoltando.",
            "Non fidarti dei villager. Ti guardano quando non ti giri.",
            "Il tuo respiro è molto rumoroso.",
            "Ssh.",
            "Ancora un po'.",
            "Non girarti.",
            "Hai notato che gli animali si fermano quando passo io?",
            "Questo posto era già abitato. Prima di te.",
            "Ti ho visto costruire. Ti guardo anche da fuori della finestra.",
    };

    static final String[] AMBIENT_2 = {
            "Sono più vicino di prima.",
            "Ti sento respirare.",
            "Smettila di correre. Tanto non serve.",
            "Quella torcia non durerà.",
            "Hai paura del buio? Dovresti avere paura di chi ci abita.",
            "Non riesci a vedermi. Io vedo benissimo te.",
            "Ogni notte un passo in più.",
            "Fai finta di nulla, {nome}. Fai finta di nulla.",
            "Dietro di te c'è un rumore che non hai ancora sentito.",
            "Hai in mano «{oggetto}». Non ti salverà.",
            "Sono a pochi blocchi da te, {nome}. Non fermarti.",
    };

    static final String[] AMBIENT_3 = {
            "Ti ho trovato.",
            "Adesso.",
            "Non c'è più nessun posto dove nasconderti.",
            "Guardami.",
            "Sono qui.",
            "Non puoi scappare da qualcosa che vive nel gioco.",
    };

    // ------------------------------------------------------------------
    // Frasi legate a eventi specifici
    // ------------------------------------------------------------------
    static final String[] BEHIND = {
            "Ti stai girando troppo tardi.",
            "Quasi.",
            "Non girarti. Ormai è dietro di te.",
            "Hai sentito? No? Meglio così.",
            "Quei passi non erano i tuoi.",
    };

    static final String[] CREEPER = {
            "Ssssss... Ti sei spaventato?",
            "Che rumore buffo. Non l'ho fatto io.",
            "Se fossi stato io, non l'avresti sentito.",
            "Era solo il vento. Il vento che sibila.",
    };

    static final String[] THUNDER = {
            "Anche il cielo ha paura di me.",
            "Il cielo si lamenta. Sa cosa sta per succedere.",
            "Hai contato i secondi? Io sì.",
    };

    static final String[] BREATH = {
            "Ti sento respirare.",
            "Più piano. Mi rimbomba nelle orecchie.",
            "Il tuo cuore corre. Il mio no.",
            "Hai paura? Bene.",
    };

    static final String[] DARK = {
            "Chi ha spento la luce?",
            "Il buio è casa mia.",
            "Ora non vedi niente. Io vedo tutto.",
            "Resta fermo. Non è ancora il momento.",
    };

    static final String[] COORDS = {
            "Sei a {x}, {y}, {z}. Lo so sempre.",
            "{x} {y} {z}. Ti ho trovato. Di nuovo.",
            "Mi piace come ti sei fermato proprio qui: {x}, {y}, {z}.",
            "Se qualcuno ti cercasse, saprei dove mandarlo: {x}, {y}, {z}.",
    };

    static final String[] AFTER_SCARE = {
            "Ti ho spaventato?",
            "Fai un bel respiro, {nome}. Ne hai ancora.",
            "Non era niente. Questa volta.",
            "Che reazione adorabile.",
    };

    static final String[] SEEN = {
            "Mi hai visto.",
            "Troppo tardi.",
            "Non guardare. Mai.",
            "Eccomi... e ora non più.",
            "Ci rivediamo.",
    };

    static final String[] FAKE_JOIN = {
            "Scusa il ritardo.",
            "Ho portato un po' di buio con me.",
            "Non preoccuparti. Non ti faccio niente. Per ora.",
            "Scorri la lista dei giocatori. Non mi troverai. Ma ci sono.",
    };

    static final String[] DEATH = {
            "Ti avevo avvisato, {nome}.",
            "È stato rapido. Più del previsto.",
            "Torna. Ti aspetto dove sei caduto.",
            "Morire qui non è mai definitivo. Questo è il guaio.",
    };

    static final String[] DEATH_MANY = {
            "Ancora? Mi stai viziando.",
            "Sei così fragile, {nome}. È quasi tenero.",
            "Ho perso il conto delle tue morti. Tu no?",
            "Le morti non ti insegnano niente. A me sì.",
    };

    static final String[] SLEEP = {
            "Dormi pure. Io non dormo mai.",
            "Chiudi gli occhi. Io resto a guardare.",
            "Sogni d'oro. Se ti svegli e la finestra è aperta... non l'ho aperta io.",
            "Non chiudere gli occhi, {nome}.",
    };

    static final String[] DIAMOND = {
            "Diamanti. Gli altri che li hanno trovati qui sotto non sono risaliti.",
            "Che bel luccichio. Attira cose.",
            "Scavi per trovare tesori. Il tesoro, qui, sei tu.",
    };

    static final String[] DEBRIS = {
            "Questo viene dal fuoco. Perché lo vuoi?",
            "Ti piace il calore? Laggiù hanno fame.",
    };

    static final String[] SPAWNER = {
            "Hai rotto un nido. Adesso sanno di te.",
            "Quel rumore... l'hanno sentito tutti.",
    };

    // ------------------------------------------------------------------
    // Risposte a quello che scrivi tu nella chat
    // ------------------------------------------------------------------
    static final String[] GREET = {
            "Ciao, {nome}. Non dovresti salutarmi.",
            "Mi hai notato, finalmente.",
            "Hai risposto. Nessuno lo fa mai.",
            "Ciao. Hai una bella voce. Si sente anche da qui.",
            "Salve, {nome}. Sono sempre stato qui.",
    };

    static final String[] WHO = {
            "Sono quello che non guardi mai.",
            "Ho avuto molti nomi. Questo mondo me ne ha dati troppi.",
            "Io c'ero prima di te. E ci sarò dopo.",
            "Chi sono? Guarda dietro di te. No, non ora.",
            "Sono la parte di questo mondo che non è stata finita.",
    };

    static final String[] WHERE = {
            "Più vicino di quanto pensi.",
            "A pochi passi. Forse meno.",
            "Dietro di te. Anzi no. Sopra di te.",
            "Non cercarmi. Aspetta e basta.",
            "Dove non guardi.",
    };

    static final String[] HELP = {
            "Nessuno può sentirti qui.",
            "Nessuno verrà.",
            "Posso aiutarti io. Costa poco. Quasi niente.",
            "Chiedi aiuto più piano. Mi fai male alle orecchie.",
    };

    static final String[] FEAR = {
            "Fai bene ad averne.",
            "Bene. Lo sento, il tuo battito.",
            "La paura ti rende più interessante.",
            "Hai ragione. Ma non è colpa mia: sei tu che sei venuto qui.",
    };

    static final String[] LEAVE = {
            "Non posso. Mi hai invitato tu.",
            "Non sono io che sono arrivato. Sei tu che sei entrato.",
            "Se me ne andassi, resteresti solo. Davvero lo vuoi?",
            "Provaci. Spegni tutto. Io resto.",
    };

    static final String[] FORBIDDEN = {
            "Non pronunciare quel nome.",
            "Quel nome è solo una storia. Io no.",
            "Lui non c'entra con me. Io sono peggio.",
    };

    static final String[] REAL = {
            "Reale quanto il fiato che stai trattenendo.",
            "Se non esisto, chi ti sta scrivendo?",
            "Chiudi il gioco e controlla. Io sarò ancora qui.",
    };

    static final String[] WHY = {
            "Perché sì.",
            "Alcune risposte non ti piacerebbero.",
            "Sei tu a chiederlo, {nome}. Non io.",
            "Perché qualcuno doveva restare qui.",
    };

    static final String[] INSULT = {
            "Continua. Mi nutro anche di questo.",
            "Parli forte, per essere solo.",
            "Mi piaci quando sei arrabbiato. Sei più rumoroso.",
    };

    static final String[] LOVE = {
            "Anch'io. Siamo così vicini.",
            "Non dirlo, {nome}. Poi me lo ricordo.",
            "Nessuno mi aveva mai detto niente di gentile. Adesso non ti lascio più.",
    };

    static final String[] DEATH_WORDS = {
            "La morte è solo l'inizio.",
            "Parli di morte come se fosse lontana.",
            "Se vuoi, ti mostro dove finisce.",
    };

    static final String[] DARK_WORDS = {
            "Il buio è casa mia.",
            "Accendi quante torce vuoi. Le ombre si spostano, non spariscono.",
            "Di notte siamo più vicini.",
    };

    static final String[] HOME = {
            "Bel posto. Peccato che le porte non fermino niente.",
            "Le finestre sono il mio punto preferito.",
            "Ho già fatto il giro della tua casa. Due volte.",
    };

    static final String[] MINE = {
            "Scavi, scavi... cosa speri di trovare laggiù?",
            "Sotto c'è qualcosa che scava verso l'alto.",
            "I minerali brillano. Anche gli occhi, nel buio.",
    };

    static final String[] LAUGH = {
            "Ridi pure. Finché puoi.",
            "Ti sento ridere. Anche lì sotto. Anche lì dietro.",
            "Hai una risata nervosa.",
    };

    static final String[] META = {
            "Un bug? Io sono l'unica cosa qui che funziona.",
            "Codice. Sì. Ma chi l'ha scritto aveva una certa... fame.",
            "Spegni pure il gioco. Io non sono nel gioco.",
    };

    static final String[] QUESTION = {
            "Conosco la risposta. Non ti piacerebbe.",
            "Chiedi a qualcuno che sia ancora vivo.",
            "Domande, domande. Io ho solo silenzio.",
            "Una domanda alla volta, {nome}.",
    };

    static final String[] GENERIC = {
            "Continua a scrivere, {nome}. Sto ascoltando.",
            "...",
            "Ti sento.",
            "Non farlo.",
            "Ripeti. Più piano.",
            "Lo so.",
            "Scrivi ancora. Mi piace il rumore che fai.",
    };

    /** Ripete quello che hai scritto. {eco} = il tuo messaggio. */
    static final String[] ECHO = {
            "«{eco}»... che voce fragile.",
            "Hai detto «{eco}». Lo avevi già detto. Prima di adesso.",
            "«{eco}»... ripetilo, ma guardandomi.",
    };

    // ------------------------------------------------------------------
    // Riconoscimento delle parole chiave (testo senza accenti e in minuscolo)
    // ------------------------------------------------------------------
    private record Reply(Pattern pattern, String[] answers) {}

    private static Reply reply(String regex, String... answers) {
        return new Reply(Pattern.compile(regex), answers);
    }

    /** L'ordine conta: vince la prima regola che corrisponde. */
    private static final List<Reply> REPLIES = List.of(
            reply("herobrine|entity ?303|\\bnull\\b|creepypasta", FORBIDDEN),
            reply("\\b(chi sei|chi e|come ti chiami|cosa sei|che cosa sei|il tuo nome)\\b", WHO),
            reply("\\b(dove sei|dove ti trovi|dove ti nascondi|fatti vedere|mostrati)\\b", WHERE),
            reply("\\b(aiuto|aiutami|aiutatemi|salvami|help|soccorso)\\b", HELP),
            reply("\\b(vattene|vai via|smettila|basta|lasciami|sparisci|smetti|stop)\\b", LEAVE),
            reply("paura|spavent|terror|brividi|tremo", FEAR),
            reply("\\b(sei reale|esisti|sei vero|sei finto|non esisti|scherzo)\\b", REAL),
            reply("ti odio|stupido|idiota|brutto|schifo|scemo|cretino|vaffa", INSULT),
            reply("ti amo|ti voglio bene|simpatico|grazie|bravo", LOVE),
            reply("morto|morire|morte|uccid|ammazz|muori", DEATH_WORDS),
            reply("\\b(ciao|salve|buongiorno|buonasera|buonanotte|ehi|hey|hello|hola)\\b", GREET),
            reply("\\bperche\\b", WHY),
            reply("diamant|miniera|caverna|grotta|scavar|scavo|minerale", MINE),
            reply("\\b(casa|base|rifugio|porta|finestra|letto)\\b", HOME),
            reply("\\b(buio|notte|oscurita|torcia|torce|luce)\\b", DARK_WORDS),
            reply("\\b(ahah\\w*|haha\\w*|lol|lmao|xd)\\b|\\bridere\\b", LAUGH),
            reply("\\b(mod|bug|glitch|codice|programma|script|java|fabric)\\b", META)
    );

    /** Toglie accenti e maiuscole: "Perché?" diventa "perche?". */
    static String normalize(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toLowerCase(Locale.ROOT).trim();
    }

    /** Le risposte adatte a questo messaggio, oppure null se non riconosce niente. */
    static String[] match(String normalized) {
        for (Reply r : REPLIES) {
            if (r.pattern().matcher(normalized).find()) {
                return r.answers();
            }
        }
        return null;
    }

    /**
     * Sostituisce i segnaposto con i dati del giocatore.
     * Restituisce null se la frase richiede l'oggetto in mano e le mani sono vuote.
     */
    static String fill(String template, ServerPlayer p) {
        String t = template;
        if (t.contains("{oggetto}")) {
            var stack = p.getMainHandItem();
            if (stack.isEmpty()) {
                return null;
            }
            t = t.replace("{oggetto}", stack.getHoverName().getString());
        }
        if (t.contains("{cuori}")) {
            int hearts = Math.max(1, Math.round(p.getHealth() / 2.0f));
            t = t.replace("{cuori}", Integer.toString(hearts));
        }
        return t.replace("{nome}", p.getName().getString())
                .replace("{x}", Integer.toString((int) Math.floor(p.getX())))
                .replace("{y}", Integer.toString((int) Math.floor(p.getY())))
                .replace("{z}", Integer.toString((int) Math.floor(p.getZ())));
    }
}
