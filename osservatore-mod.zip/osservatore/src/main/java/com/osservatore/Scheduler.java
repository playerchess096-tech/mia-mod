package com.osservatore;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Piccolo pianificatore: esegue un'azione dopo N tick del server (20 tick = 1 secondo). */
final class Scheduler {

    private record Task(long due, Runnable action) {}

    private final ConcurrentLinkedQueue<Task> incoming = new ConcurrentLinkedQueue<>();
    private final List<Task> pending = new ArrayList<>();
    private volatile long now;

    /** Esegue {@code action} fra {@code ticks} tick (minimo 1). */
    void after(int ticks, Runnable action) {
        incoming.add(new Task(now + Math.max(1, ticks), action));
    }

    /** Da chiamare una volta per tick del server. */
    void tick() {
        now++;
        Task t;
        while ((t = incoming.poll()) != null) {
            pending.add(t);
        }

        List<Task> due = new ArrayList<>();
        Iterator<Task> it = pending.iterator();
        while (it.hasNext()) {
            Task task = it.next();
            if (task.due() <= now) {
                due.add(task);
                it.remove();
            }
        }

        due.sort(Comparator.comparingLong(Task::due));
        for (Task task : due) {
            try {
                task.action().run();
            } catch (RuntimeException e) {
                OsservatoreMod.LOGGER.warn("Un'azione pianificata è fallita", e);
            }
        }
    }

    void clear() {
        incoming.clear();
        pending.clear();
    }
}
