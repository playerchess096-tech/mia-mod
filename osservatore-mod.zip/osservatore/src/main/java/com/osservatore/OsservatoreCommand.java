package com.osservatore;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;

/**
 * Il comando /osservatore (serve il livello "gamemaster": in un mondo singolo vanno attivati i trucchi).
 *
 *   /osservatore                      stato e lista degli eventi
 *   /osservatore evento               un evento a caso, subito
 *   /osservatore evento <nome>        un evento preciso (tab per vedere i nomi)
 *   /osservatore parla <testo>        l'Osservatore scrive nella tua chat
 *   /osservatore intensita <0-3>      0 spento, 1 lieve, 2 normale, 3 incubo
 *   /osservatore pulisci              toglie le figure lontane rimaste nel mondo
 */
final class OsservatoreCommand {

    private OsservatoreCommand() {}

    static void register(CommandDispatcher<CommandSourceStack> dispatcher, Director director, Config cfg) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("osservatore")
                .requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER))
                .executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(director.statusText()), false);
                    return 1;
                });

        LiteralArgumentBuilder<CommandSourceStack> evento = Commands.literal("evento")
                .executes(ctx -> {
                    director.randomNow(ctx.getSource().getPlayerOrException());
                    return 1;
                });
        for (String id : Director.EVENT_IDS) {
            evento.then(Commands.literal(id).executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                if (!director.trigger(player, id)) {
                    ctx.getSource().sendFailure(Component.literal(
                            "Non è stato possibile lanciare «" + id + "» qui (forse non c'è spazio libero attorno a te)."));
                    return 0;
                }
                return 1;
            }));
        }
        root.then(evento);

        root.then(Commands.literal("parla").then(
                Commands.argument("testo", StringArgumentType.greedyString()).executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    director.say(player, StringArgumentType.getString(ctx, "testo"), false);
                    return 1;
                })));

        root.then(Commands.literal("intensita").then(
                Commands.argument("livello", IntegerArgumentType.integer(0, 3)).executes(ctx -> {
                    int level = IntegerArgumentType.getInteger(ctx, "livello");
                    cfg.intensity = level;
                    cfg.save();
                    ctx.getSource().sendSuccess(() -> Component.literal("Intensità impostata a " + level + "."), false);
                    return level;
                })));

        root.then(Commands.literal("pulisci").executes(ctx -> {
            int removed = director.clearStalkers();
            ctx.getSource().sendSuccess(() -> Component.literal("Figure rimosse: " + removed + "."), false);
            return removed;
        }));

        dispatcher.register(root);
    }
}
