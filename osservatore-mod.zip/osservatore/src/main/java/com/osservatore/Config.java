package com.osservatore;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Impostazioni. Si leggono da config/osservatore.properties (il file si crea da solo al primo avvio). */
final class Config {

    /** 0 = spento, 1 = lieve, 2 = normale, 3 = incubo. */
    volatile int intensity = 2;
    /** Nome con cui parla nella chat. */
    volatile String entityName = "Osservatore";
    volatile int minSeconds = 120;
    volatile int maxSeconds = 300;
    /** Probabilità (0-100) di rispondere a frasi che non conosce. */
    volatile int chatReplyChance = 30;
    volatile boolean jumpscare = true;
    volatile boolean stalker = true;
    volatile boolean fakeJoin = true;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("osservatore.properties");
    }

    static Config load() {
        Config c = new Config();
        Path f = file();
        if (Files.exists(f)) {
            try (Reader reader = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                Properties p = new Properties();
                p.load(reader);
                c.intensity = clamp(readInt(p, "intensita", c.intensity), 0, 3);
                String name = p.getProperty("nome", c.entityName).trim();
                if (!name.isEmpty()) {
                    c.entityName = name;
                }
                c.minSeconds = Math.max(5, readInt(p, "secondi_min", c.minSeconds));
                c.maxSeconds = Math.max(c.minSeconds + 1, readInt(p, "secondi_max", c.maxSeconds));
                c.chatReplyChance = clamp(readInt(p, "probabilita_risposta", c.chatReplyChance), 0, 100);
                c.jumpscare = readBool(p, "jumpscare", c.jumpscare);
                c.stalker = readBool(p, "ombra", c.stalker);
                c.fakeJoin = readBool(p, "falso_ingresso", c.fakeJoin);
            } catch (IOException | RuntimeException e) {
                OsservatoreMod.LOGGER.warn("Impossibile leggere {}: uso i valori predefiniti", f, e);
            }
        }
        c.save();
        return c;
    }

    /** Riscrive il file (con i commenti) usando i valori attuali. */
    synchronized void save() {
        String text = """
                # L'Osservatore - impostazioni
                # (se rompi qualcosa cancella questo file: ne viene creato uno nuovo)
                #
                # intensita: 0 = spento, 1 = lieve, 2 = normale, 3 = incubo
                intensita=%d
                # nome con cui parla nella chat
                nome=%s
                # ogni quanti secondi (da-a) puo' succedere qualcosa
                secondi_min=%d
                secondi_max=%d
                # probabilita' (0-100) che risponda a una frase che non conosce
                probabilita_risposta=%d
                # spaventi forti: schermo che trema, urlo, titolo
                jumpscare=%b
                # la figura lontana che sparisce quando la guardi
                ombra=%b
                # il finto messaggio "e' entrato nel gioco"
                falso_ingresso=%b
                """.formatted(intensity, entityName, minSeconds, maxSeconds, chatReplyChance,
                jumpscare, stalker, fakeJoin);
        Path f = file();
        try {
            Files.createDirectories(f.getParent());
            try (Writer writer = Files.newBufferedWriter(f, StandardCharsets.UTF_8)) {
                writer.write(text);
            }
        } catch (IOException e) {
            OsservatoreMod.LOGGER.warn("Impossibile salvare {}", f, e);
        }
    }

    private static int readInt(Properties p, String key, int fallback) {
        try {
            return Integer.parseInt(p.getProperty(key, Integer.toString(fallback)).trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static boolean readBool(Properties p, String key, boolean fallback) {
        String v = p.getProperty(key);
        return v == null ? fallback : Boolean.parseBoolean(v.trim());
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
